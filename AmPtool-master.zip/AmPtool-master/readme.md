AmPtool is Matlab code, a daughter-project of DEBtool_M, that can be used for the analysis of the Add_my_Pet data-base
https://bio.vu.nl/thb/deb/deblab/
